const settings = {
  packname: 'MAD-MAX',
  author: 'LIVE-WARE‎',
  botName: "MAD-MAX[BUG]-V1",
  botOwner: 'BOIASTRO', // Your name
  ownerNumber: '263719806064','2347020185206','989136773794', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  description: "This is a bot for phone crashing[time we pay our old deeds]",
  version: "1.0.0",
};

module.exports = settings;
